const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Add web proxy configuration to handle CORS issues
config.web = {
  ...config.web,
  output: {
    ...config.web?.output,
    unstable_proxies: {
      '/mac-api': {
        target: 'http://portal.mac',
        changeOrigin: true,
        pathRewrite: {
          '^/mac-api': ''
        }
      }
    }
  }
};

module.exports = config;
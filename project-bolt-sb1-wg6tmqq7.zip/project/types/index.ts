export interface Channel {
  id: string;
  name: string;
  url: string;
  logo?: string;
  country?: string;
  category?: string;
  language?: string;
  providerId?: string;
}

export interface Provider {
  id: string;
  name: string;
  type: 'mac' | 'm3u';
  url: string;
  macAddress?: string;
  username?: string;
  password?: string;
  isActive: boolean;
  channelCount?: number;
  lastUpdated: string;
}

export interface PlaylistInfo {
  title?: string;
  channels: Channel[];
}

export interface CountryInfo {
  name: string;
  code: string;
  flag: string;
  channelCount: number;
}
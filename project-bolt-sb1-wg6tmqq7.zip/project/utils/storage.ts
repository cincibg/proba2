import AsyncStorage from '@react-native-async-storage/async-storage';
import { Provider, Channel } from '@/types';

const PROVIDERS_KEY = 'iptv_providers';
const CHANNELS_KEY = 'iptv_channels';
const FAVORITES_KEY = 'iptv_favorites';

// Provider Storage
export const getStoredProviders = async (): Promise<Provider[]> => {
  try {
    const data = await AsyncStorage.getItem(PROVIDERS_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error getting providers:', error);
    return [];
  }
};

export const saveProvider = async (provider: Provider): Promise<void> => {
  try {
    const providers = await getStoredProviders();
    const existingIndex = providers.findIndex(p => p.id === provider.id);
    
    if (existingIndex >= 0) {
      providers[existingIndex] = provider;
    } else {
      providers.push(provider);
    }
    
    await AsyncStorage.setItem(PROVIDERS_KEY, JSON.stringify(providers));
  } catch (error) {
    console.error('Error saving provider:', error);
    throw error;
  }
};

export const deleteProvider = async (providerId: string): Promise<void> => {
  try {
    const providers = await getStoredProviders();
    const filteredProviders = providers.filter(p => p.id !== providerId);
    await AsyncStorage.setItem(PROVIDERS_KEY, JSON.stringify(filteredProviders));
  } catch (error) {
    console.error('Error deleting provider:', error);
    throw error;
  }
};

// Channel Storage
export const getStoredChannels = async (): Promise<Channel[]> => {
  try {
    const data = await AsyncStorage.getItem(CHANNELS_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error getting channels:', error);
    return [];
  }
};

export const saveChannels = async (channels: Channel[]): Promise<void> => {
  try {
    console.log(`Saving ${channels.length} channels to storage`);
    await AsyncStorage.setItem(CHANNELS_KEY, JSON.stringify(channels));
  } catch (error) {
    console.error('Error saving channels:', error);
    throw error;
  }
};

// Get channels by country
export const getChannelsByCountry = async (country: string): Promise<Channel[]> => {
  try {
    const channels = await getStoredChannels();
    return channels.filter(channel => channel.country === country);
  } catch (error) {
    console.error('Error getting channels by country:', error);
    return [];
  }
};

// Get channels by category
export const getChannelsByCategory = async (category: string): Promise<Channel[]> => {
  try {
    const channels = await getStoredChannels();
    return channels.filter(channel => channel.category === category);
  } catch (error) {
    console.error('Error getting channels by category:', error);
    return [];
  }
};

// Get channels by provider
export const getChannelsByProvider = async (providerId: string): Promise<Channel[]> => {
  try {
    const channels = await getStoredChannels();
    return channels.filter(channel => channel.providerId === providerId);
  } catch (error) {
    console.error('Error getting channels by provider:', error);
    return [];
  }
};
// Favorites Storage
export const getFavoriteChannels = async (): Promise<string[]> => {
  try {
    const data = await AsyncStorage.getItem(FAVORITES_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error getting favorites:', error);
    return [];
  }
};

export const saveFavoriteChannels = async (favorites: string[]): Promise<void> => {
  try {
    await AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
  } catch (error) {
    console.error('Error saving favorites:', error);
    throw error;
  }
};

// Clear all data
export const clearAllData = async (): Promise<void> => {
  try {
    await AsyncStorage.multiRemove([PROVIDERS_KEY, CHANNELS_KEY, FAVORITES_KEY]);
  } catch (error) {
    console.error('Error clearing data:', error);
    throw error;
  }
};
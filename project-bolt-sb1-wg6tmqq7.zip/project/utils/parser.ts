import { Channel, PlaylistInfo } from '@/types';

// MAC Address validation
export const validateMACAddress = (mac: string): boolean => {
  // Check if MAC starts with 00:A1:79: and has correct format
  const macRegex = /^00:A1:79:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}$/;
  return macRegex.test(mac);
};

// Fetch channels from MAC provider
export const fetchMACChannels = async (provider: { url: string; macAddress?: string; username?: string; password?: string }): Promise<Channel[]> => {
  try {
    if (!provider.macAddress) {
      throw new Error('MAC address is required');
    }

    // Use proxy path to avoid CORS issues in web development
    const apiUrl = `/mac-api/portal.php?type=itv&action=get_all_channels&mac=${provider.macAddress}`;
    
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
        'X-User-Agent': 'Model: MAG250; Link: WiFi',
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const responseText = await response.text();
    
    // Check if response is HTML (error page) instead of JSON
    if (responseText.trim().startsWith('<!DOCTYPE') || responseText.trim().startsWith('<html')) {
      throw new Error('Server returned HTML instead of JSON. Please check your MAC provider URL.');
    }
    
    let data;
    try {
      data = JSON.parse(responseText);
    } catch (parseError) {
      throw new Error(`Invalid JSON response: ${parseError.message}`);
    }
    
    if (data.js && Array.isArray(data.js)) {
      return data.js.map((channel: any, index: number) => ({
        id: `mac_${provider.macAddress}_${channel.id || index}`,
        name: channel.name || `Channel ${index + 1}`,
        url: channel.cmd || '',
        logo: channel.logo || '',
        country: extractCountryFromName(channel.name) || 'Unknown',
        category: channel.tv_genre_title || extractCategoryFromName(channel.name),
        language: 'Unknown',
        providerId: `mac_${provider.macAddress}`,
      }));
    }

    return [];
  } catch (error) {
    console.error('Error fetching MAC channels:', error);
    return [];
  }
};

// M3U Playlist parser
export const parseM3U = async (url: string): Promise<PlaylistInfo> => {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const content = await response.text();
    return parseM3UContent(content);
  } catch (error) {
    console.error('Error fetching M3U playlist:', error);
    throw error;
  }
};

// Parse M3U content
export const parseM3UContent = (content: string): PlaylistInfo => {
  const lines = content.split('\n').map(line => line.trim()).filter(line => line);
  const channels: Channel[] = [];
  let currentChannel: Partial<Channel> = {};
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    if (line.startsWith('#EXTM3U')) {
      // Playlist header
      continue;
    } else if (line.startsWith('#EXTINF:')) {
      // Channel info line
      currentChannel = parseExtInf(line);
    } else if (line.startsWith('http://') || line.startsWith('https://') || line.startsWith('rtmp://') || line.startsWith('rtsp://')) {
      // Stream URL
      if (currentChannel.name) {
        const channel: Channel = {
          id: generateChannelId(),
          name: currentChannel.name,
          url: line,
          logo: currentChannel.logo || '',
          country: currentChannel.country || extractCountryFromName(currentChannel.name) || 'Unknown',
          category: currentChannel.category || extractCategoryFromName(currentChannel.name),
          language: currentChannel.language || 'Unknown',
        };
        channels.push(channel);
      }
      currentChannel = {};
    }
  }
  
  return {
    channels,
  };
};

// Parse EXTINF line
const parseExtInf = (line: string): Partial<Channel> => {
  const channel: Partial<Channel> = {};
  
  // Extract channel name (after the comma)
  const nameMatch = line.match(/,(.+)$/);
  if (nameMatch) {
    channel.name = nameMatch[1].trim();
  }
  
  // Extract attributes
  const attributes = extractAttributes(line);
  
  if (attributes['tvg-logo']) {
    channel.logo = attributes['tvg-logo'];
  }
  
  if (attributes['tvg-country']) {
    channel.country = getCountryName(attributes['tvg-country']);
  }
  
  if (attributes['group-title']) {
    channel.category = attributes['group-title'];
  }
  
  if (attributes['tvg-language']) {
    channel.language = attributes['tvg-language'];
  }
  
  return channel;
};

// Extract attributes from EXTINF line
const extractAttributes = (line: string): { [key: string]: string } => {
  const attributes: { [key: string]: string } = {};
  
  // Match attribute="value" patterns
  const attrRegex = /(\w+(?:-\w+)*)="([^"]*)"/g;
  let match;
  
  while ((match = attrRegex.exec(line)) !== null) {
    attributes[match[1]] = match[2];
  }
  
  return attributes;
};

// Generate unique channel ID
const generateChannelId = (): string => {
  return `channel_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

// URL validation
export const isValidURL = (url: string): boolean => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};

// Extract country from channel name or attributes
export const extractCountryFromName = (name: string): string | undefined => {
  if (!name) return undefined;
  
  const countryPatterns = [
    // Country codes in brackets
    { pattern: /\[([A-Z]{2})\]/i, type: 'code' },
    { pattern: /\(([A-Z]{2})\)/i, type: 'code' },
    // Full country names
    { pattern: /\b(United States|USA|America)\b/i, name: 'United States' },
    { pattern: /\b(United Kingdom|UK|Britain|England)\b/i, name: 'United Kingdom' },
    { pattern: /\b(Germany|Deutschland)\b/i, name: 'Germany' },
    { pattern: /\b(France|Francia)\b/i, name: 'France' },
    { pattern: /\b(Spain|España)\b/i, name: 'Spain' },
    { pattern: /\b(Italy|Italia)\b/i, name: 'Italy' },
    { pattern: /\b(Russia|Россия)\b/i, name: 'Russia' },
    { pattern: /\b(China|中国)\b/i, name: 'China' },
    { pattern: /\b(Japan|日本)\b/i, name: 'Japan' },
    { pattern: /\b(India|भारत)\b/i, name: 'India' },
    { pattern: /\b(Brazil|Brasil)\b/i, name: 'Brazil' },
    { pattern: /\b(Canada)\b/i, name: 'Canada' },
    { pattern: /\b(Australia)\b/i, name: 'Australia' },
    { pattern: /\b(Netherlands|Holland)\b/i, name: 'Netherlands' },
    { pattern: /\b(Turkey|Türkiye)\b/i, name: 'Turkey' },
    { pattern: /\b(Poland|Polska)\b/i, name: 'Poland' },
    { pattern: /\b(Ukraine|Україна)\b/i, name: 'Ukraine' },
    { pattern: /\b(Argentina)\b/i, name: 'Argentina' },
    { pattern: /\b(Mexico|México)\b/i, name: 'Mexico' },
    { pattern: /\b(South Korea|Korea)\b/i, name: 'South Korea' },
    { pattern: /\b(Portugal)\b/i, name: 'Portugal' },
    { pattern: /\b(Sweden|Sverige)\b/i, name: 'Sweden' },
    { pattern: /\b(Norway|Norge)\b/i, name: 'Norway' },
    { pattern: /\b(Denmark|Danmark)\b/i, name: 'Denmark' },
    { pattern: /\b(Finland|Suomi)\b/i, name: 'Finland' },
    { pattern: /\b(Belgium|België)\b/i, name: 'Belgium' },
    { pattern: /\b(Switzerland|Schweiz)\b/i, name: 'Switzerland' },
    { pattern: /\b(Austria|Österreich)\b/i, name: 'Austria' },
    { pattern: /\b(Greece|Ελλάδα)\b/i, name: 'Greece' },
    { pattern: /\b(Czech Republic|Czechia)\b/i, name: 'Czech Republic' },
    { pattern: /\b(Hungary|Magyarország)\b/i, name: 'Hungary' },
    { pattern: /\b(Romania|România)\b/i, name: 'Romania' },
    { pattern: /\b(Bulgaria|България)\b/i, name: 'Bulgaria' },
    { pattern: /\b(Croatia|Hrvatska)\b/i, name: 'Croatia' },
    { pattern: /\b(Serbia|Србија)\b/i, name: 'Serbia' },
    { pattern: /\b(Slovenia|Slovenija)\b/i, name: 'Slovenia' },
    { pattern: /\b(Slovakia|Slovensko)\b/i, name: 'Slovakia' },
    { pattern: /\b(Lithuania|Lietuva)\b/i, name: 'Lithuania' },
    { pattern: /\b(Latvia|Latvija)\b/i, name: 'Latvia' },
    { pattern: /\b(Estonia|Eesti)\b/i, name: 'Estonia' },
  ];
  
  for (const { pattern, type, name: countryName } of countryPatterns) {
    const match = name.match(pattern);
    if (match) {
      if (type === 'code') {
        return getCountryName(match[1].toUpperCase());
      } else if (countryName) {
        return countryName;
      }
    }
  }
  
  return undefined;
};

// Convert country code to full name
const getCountryName = (code: string): string => {
  const countryMap: { [key: string]: string } = {
    'US': 'United States',
    'UK': 'United Kingdom',
    'GB': 'United Kingdom',
    'DE': 'Germany',
    'FR': 'France',
    'ES': 'Spain',
    'IT': 'Italy',
    'RU': 'Russia',
    'CN': 'China',
    'JP': 'Japan',
    'IN': 'India',
    'BR': 'Brazil',
    'CA': 'Canada',
    'AU': 'Australia',
    'NL': 'Netherlands',
    'TR': 'Turkey',
    'PL': 'Poland',
    'UA': 'Ukraine',
    'AR': 'Argentina',
    'MX': 'Mexico',
    'KR': 'South Korea',
    'PT': 'Portugal',
    'SE': 'Sweden',
    'NO': 'Norway',
    'DK': 'Denmark',
    'FI': 'Finland',
    'BE': 'Belgium',
    'CH': 'Switzerland',
    'AT': 'Austria',
    'GR': 'Greece',
    'CZ': 'Czech Republic',
    'HU': 'Hungary',
    'RO': 'Romania',
    'BG': 'Bulgaria',
    'HR': 'Croatia',
    'RS': 'Serbia',
    'SI': 'Slovenia',
    'SK': 'Slovakia',
    'LT': 'Lithuania',
    'LV': 'Latvia',
    'EE': 'Estonia',
  };
  
  return countryMap[code] || code;
};

// Extract category from channel name
export const extractCategoryFromName = (name: string): string => {
  if (!name) return 'General';
  
  const categoryPatterns = [
    { pattern: /news|cnn|bbc|fox news|msnbc|sky news|euronews|france 24|rt|al jazeera/i, category: 'News' },
    { pattern: /sport|espn|fox sports|nba|nfl|fifa|uefa|premier league|champions league|tennis|golf|formula|boxing|mma|wrestling/i, category: 'Sports' },
    { pattern: /movie|cinema|film|hollywood|bollywood|paramount|warner|universal|sony pictures/i, category: 'Movies' },
    { pattern: /kids|cartoon|disney|nickelodeon|cartoon network|baby tv|boomerang|nick jr/i, category: 'Kids' },
    { pattern: /music|mtv|vh1|vevo|radio|concert|live music/i, category: 'Music' },
    { pattern: /discovery|national geographic|history|documentary|animal planet|science|nature|travel/i, category: 'Documentary' },
    { pattern: /entertainment|comedy|drama|reality|talk show|variety/i, category: 'Entertainment' },
    { pattern: /religious|church|islam|christian|catholic|spiritual/i, category: 'Religious' },
    { pattern: /adult|xxx|porn|erotic/i, category: 'Adult' },
    { pattern: /shopping|qvc|hsn|teleshopping/i, category: 'Shopping' },
    { pattern: /cooking|food|recipe|kitchen/i, category: 'Lifestyle' },
    { pattern: /weather|forecast|climate/i, category: 'Weather' },
  ];
  
  for (const { pattern, category } of categoryPatterns) {
    if (pattern.test(name)) {
      return category;
    }
  }
  
  return 'General';
};
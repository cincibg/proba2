import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Play, Pause, Volume2, VolumeX, RotateCcw, Tv } from 'lucide-react-native';
import { getStoredProviders, getStoredChannels } from '@/utils/storage';
import { Channel, Provider } from '@/types';

export default function LiveTVScreen() {
  const [currentChannel, setCurrentChannel] = useState<Channel | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [recentChannels, setRecentChannels] = useState<Channel[]>([]);
  const [providers, setProviders] = useState<Provider[]>([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const storedProviders = await getStoredProviders();
      const storedChannels = await getStoredChannels();
      setProviders(storedProviders);
      setRecentChannels(storedChannels.slice(0, 10));
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const playChannel = async (channel: Channel) => {
    setIsLoading(true);
    try {
      // Simulate loading time
      await new Promise(resolve => setTimeout(resolve, 1000));
      setCurrentChannel(channel);
      setIsPlaying(true);
      setIsLoading(false);
    } catch (error) {
      setIsLoading(false);
      Alert.alert('Error', 'Failed to load channel');
    }
  };

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const refreshStream = () => {
    if (currentChannel) {
      playChannel(currentChannel);
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Video Player Area */}
        <View style={styles.playerContainer}>
          {currentChannel ? (
            <View style={styles.videoPlayer}>
              {isLoading ? (
                <View style={styles.loadingContainer}>
                  <ActivityIndicator size="large" color="#3B82F6" />
                  <Text style={styles.loadingText}>Loading stream...</Text>
                </View>
              ) : (
                <>
                  <Image
                    source={{ uri: currentChannel.logo || 'https://via.placeholder.com/400x225/1F2937/FFFFFF?text=Live+TV' }}
                    style={styles.channelLogo}
                    resizeMode="contain"
                  />
                  <View style={styles.playerOverlay}>
                    <Text style={styles.channelName}>{currentChannel.name}</Text>
                    <Text style={styles.channelInfo}>
                      {currentChannel.country} • {currentChannel.category}
                    </Text>
                  </View>
                </>
              )}
            </View>
          ) : (
            <View style={styles.noChannelContainer}>
              <Tv size={64} color="#6B7280" />
              <Text style={styles.noChannelText}>Select a channel to start watching</Text>
            </View>
          )}

          {/* Player Controls */}
          {currentChannel && !isLoading && (
            <View style={styles.controls}>
              <TouchableOpacity
                style={styles.controlButton}
                onPress={togglePlayPause}
              >
                {isPlaying ? (
                  <Pause size={24} color="#FFFFFF" />
                ) : (
                  <Play size={24} color="#FFFFFF" />
                )}
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.controlButton}
                onPress={toggleMute}
              >
                {isMuted ? (
                  <VolumeX size={24} color="#FFFFFF" />
                ) : (
                  <Volume2 size={24} color="#FFFFFF" />
                )}
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.controlButton}
                onPress={refreshStream}
              >
                <RotateCcw size={24} color="#FFFFFF" />
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Recent Channels */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Channels</Text>
          {recentChannels.length > 0 ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {recentChannels.map((channel, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.channelCard}
                  onPress={() => playChannel(channel)}
                >
                  <Image
                    source={{ uri: channel.logo || 'https://via.placeholder.com/80x80/374151/FFFFFF?text=TV' }}
                    style={styles.channelCardLogo}
                  />
                  <Text style={styles.channelCardName} numberOfLines={2}>
                    {channel.name}
                  </Text>
                  <Text style={styles.channelCardCountry}>
                    {channel.country}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          ) : (
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateText}>
                No channels available. Add providers to get started.
              </Text>
            </View>
          )}
        </View>

        {/* Provider Status */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Active Providers</Text>
          {providers.length > 0 ? (
            providers.map((provider, index) => (
              <View key={index} style={styles.providerCard}>
                <View style={styles.providerInfo}>
                  <Text style={styles.providerName}>{provider.name}</Text>
                  <Text style={styles.providerType}>
                    {provider.type.toUpperCase()} • {provider.channelCount || 0} channels
                  </Text>
                </View>
                <View style={[
                  styles.statusIndicator,
                  { backgroundColor: provider.isActive ? '#10B981' : '#EF4444' }
                ]} />
              </View>
            ))
          ) : (
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateText}>
                No providers configured. Go to Providers tab to add one.
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollView: {
    flex: 1,
  },
  playerContainer: {
    backgroundColor: '#1F2937',
    margin: 16,
    borderRadius: 12,
    overflow: 'hidden',
  },
  videoPlayer: {
    height: 225,
    backgroundColor: '#000000',
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#FFFFFF',
    marginTop: 12,
    fontSize: 16,
  },
  channelLogo: {
    width: 120,
    height: 80,
  },
  playerOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    padding: 12,
  },
  channelName: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  channelInfo: {
    color: '#D1D5DB',
    fontSize: 14,
    marginTop: 4,
  },
  noChannelContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  noChannelText: {
    color: '#6B7280',
    fontSize: 16,
    marginTop: 12,
    textAlign: 'center',
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#374151',
  },
  controlButton: {
    backgroundColor: '#4B5563',
    padding: 12,
    borderRadius: 8,
    marginHorizontal: 8,
  },
  section: {
    margin: 16,
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  channelCard: {
    backgroundColor: '#1F2937',
    borderRadius: 8,
    padding: 12,
    marginRight: 12,
    width: 120,
    alignItems: 'center',
  },
  channelCardLogo: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginBottom: 8,
  },
  channelCardName: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 4,
  },
  channelCardCountry: {
    color: '#9CA3AF',
    fontSize: 10,
  },
  emptyState: {
    backgroundColor: '#1F2937',
    borderRadius: 8,
    padding: 24,
    alignItems: 'center',
  },
  emptyStateText: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
  providerCard: {
    backgroundColor: '#1F2937',
    borderRadius: 8,
    padding: 16,
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  providerInfo: {
    flex: 1,
  },
  providerName: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  providerType: {
    color: '#9CA3AF',
    fontSize: 14,
    marginTop: 4,
  },
  statusIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
});
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  TextInput,
} from 'react-native';
import { Search, Tv, ChevronRight } from 'lucide-react-native';
import { getStoredChannels } from '@/utils/storage';
import { Channel } from '@/types';

interface CountryData {
  name: string;
  code: string;
  flag: string;
  channelCount: number;
  channels: Channel[];
}

export default function CountriesScreen() {
  const [countries, setCountries] = useState<CountryData[]>([]);
  const [filteredCountries, setFilteredCountries] = useState<CountryData[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<CountryData | null>(null);

  useEffect(() => {
    loadCountries();
  }, []);

  useEffect(() => {
    filterCountries();
  }, [countries, searchQuery]);

  const loadCountries = async () => {
    try {
      const channels = await getStoredChannels();
      console.log(`Processing ${channels.length} channels for countries view`);
      
      // Group channels by country
      const countryMap = new Map<string, Channel[]>();
      
      channels.forEach(channel => {
        const country = channel.country || 'Unknown';
        if (!countryMap.has(country)) {
          countryMap.set(country, []);
        }
        countryMap.get(country)!.push(channel);
      });

      // Convert to CountryData array
      const countryData: CountryData[] = Array.from(countryMap.entries()).map(([name, channels]) => ({
        name,
        code: getCountryCode(name),
        flag: getCountryFlag(name),
        channelCount: channels.length,
        channels,
      })).sort((a, b) => b.channelCount - a.channelCount);

      console.log(`Found ${countryData.length} countries with channels`);
      setCountries(countryData);
    } catch (error) {
      console.error('Error loading countries:', error);
    }
  };

  const filterCountries = () => {
    if (!searchQuery) {
      setFilteredCountries(countries);
      return;
    }

    const filtered = countries.filter(country =>
      country.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setFilteredCountries(filtered);
  };

  const getCountryCode = (countryName: string): string => {
    const codes: { [key: string]: string } = {
      'United States': 'US',
      'United Kingdom': 'GB',
      'Germany': 'DE',
      'France': 'FR',
      'Spain': 'ES',
      'Italy': 'IT',
      'Russia': 'RU',
      'China': 'CN',
      'Japan': 'JP',
      'India': 'IN',
      'Brazil': 'BR',
      'Canada': 'CA',
      'Australia': 'AU',
      'Netherlands': 'NL',
      'Turkey': 'TR',
      'Poland': 'PL',
      'Ukraine': 'UA',
      'Argentina': 'AR',
      'Mexico': 'MX',
      'South Korea': 'KR',
    };
    return codes[countryName] || 'XX';
  };

  const getCountryFlag = (countryName: string): string => {
    const flags: { [key: string]: string } = {
      'United States': '🇺🇸',
      'United Kingdom': '🇬🇧',
      'Germany': '🇩🇪',
      'France': '🇫🇷',
      'Spain': '🇪🇸',
      'Italy': '🇮🇹',
      'Russia': '🇷🇺',
      'China': '🇨🇳',
      'Japan': '🇯🇵',
      'India': '🇮🇳',
      'Brazil': '🇧🇷',
      'Canada': '🇨🇦',
      'Australia': '🇦🇺',
      'Netherlands': '🇳🇱',
      'Turkey': '🇹🇷',
      'Poland': '🇵🇱',
      'Ukraine': '🇺🇦',
      'Argentina': '🇦🇷',
      'Mexico': '🇲🇽',
      'South Korea': '🇰🇷',
    };
    return flags[countryName] || '🌍';
  };

  const renderCountry = ({ item }: { item: CountryData }) => (
    <TouchableOpacity
      style={styles.countryItem}
      onPress={() => setSelectedCountry(item)}
    >
      <View style={styles.countryFlag}>
        <Text style={styles.flagEmoji}>{item.flag}</Text>
      </View>
      
      <View style={styles.countryInfo}>
        <Text style={styles.countryName}>{item.name}</Text>
        <Text style={styles.channelCount}>
          {item.channelCount} channels
        </Text>
      </View>
      
      <ChevronRight size={20} color="#6B7280" />
    </TouchableOpacity>
  );

  const renderChannel = ({ item }: { item: Channel }) => (
    <View style={styles.channelItem}>
      <Image
        source={{ uri: item.logo || 'https://via.placeholder.com/50x50/374151/FFFFFF?text=TV' }}
        style={styles.channelLogo}
      />
      
      <View style={styles.channelInfo}>
        <Text style={styles.channelName} numberOfLines={1}>
          {item.name}
        </Text>
        <Text style={styles.channelCategory}>
          {item.category}
        </Text>
      </View>
      
      <TouchableOpacity style={styles.playButton}>
        <Tv size={16} color="#FFFFFF" />
      </TouchableOpacity>
    </View>
  );

  if (selectedCountry) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => setSelectedCountry(null)}
          >
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          
          <View style={styles.countryHeader}>
            <Text style={styles.countryHeaderFlag}>{selectedCountry.flag}</Text>
            <View>
              <Text style={styles.countryHeaderName}>{selectedCountry.name}</Text>
              <Text style={styles.countryHeaderCount}>
                {selectedCountry.channelCount} channels
              </Text>
            </View>
          </View>
        </View>

        <FlatList
          data={selectedCountry.channels}
          keyExtractor={(item) => item.id}
          renderItem={renderChannel}
          style={styles.channelsList}
          showsVerticalScrollIndicator={false}
        />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <Search size={20} color="#6B7280" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search countries..."
          placeholderTextColor="#6B7280"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      {/* Results Header */}
      <View style={styles.resultsHeader}>
        <Text style={styles.resultsText}>
          {filteredCountries.length} countries found
        </Text>
      </View>

      {/* Countries List */}
      <FlatList
        data={filteredCountries}
        keyExtractor={(item) => item.name}
        renderItem={renderCountry}
        style={styles.countriesList}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateText}>
              {countries.length === 0
                ? 'No countries available. Add providers to load channels.'
                : 'No countries match your search criteria.'
              }
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1F2937',
    margin: 16,
    borderRadius: 8,
    paddingHorizontal: 12,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 16,
    paddingVertical: 12,
  },
  resultsHeader: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  resultsText: {
    color: '#9CA3AF',
    fontSize: 14,
  },
  countriesList: {
    flex: 1,
  },
  countryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1F2937',
    marginHorizontal: 16,
    marginBottom: 8,
    borderRadius: 8,
    padding: 16,
  },
  countryFlag: {
    marginRight: 12,
  },
  flagEmoji: {
    fontSize: 32,
  },
  countryInfo: {
    flex: 1,
  },
  countryName: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4,
  },
  channelCount: {
    color: '#9CA3AF',
    fontSize: 14,
  },
  header: {
    backgroundColor: '#1F2937',
    padding: 16,
  },
  backButton: {
    marginBottom: 12,
  },
  backButtonText: {
    color: '#3B82F6',
    fontSize: 16,
    fontWeight: '500',
  },
  countryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  countryHeaderFlag: {
    fontSize: 40,
    marginRight: 16,
  },
  countryHeaderName: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
  },
  countryHeaderCount: {
    color: '#9CA3AF',
    fontSize: 16,
    marginTop: 4,
  },
  channelsList: {
    flex: 1,
  },
  channelItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1F2937',
    marginHorizontal: 16,
    marginBottom: 8,
    borderRadius: 8,
    padding: 12,
  },
  channelLogo: {
    width: 50,
    height: 50,
    borderRadius: 6,
    marginRight: 12,
  },
  channelInfo: {
    flex: 1,
  },
  channelName: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  channelCategory: {
    color: '#9CA3AF',
    fontSize: 14,
  },
  playButton: {
    backgroundColor: '#3B82F6',
    padding: 8,
    borderRadius: 6,
  },
  emptyState: {
    padding: 32,
    alignItems: 'center',
  },
  emptyStateText: {
    color: '#9CA3AF',
    fontSize: 16,
    textAlign: 'center',
  },
});
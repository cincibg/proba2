import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Modal,
  ActivityIndicator,
} from 'react-native';
import { Plus, Settings, Trash2, Download, CircleCheck as CheckCircle, Circle as XCircle, Wifi, List } from 'lucide-react-native';
import {
  getStoredProviders,
  saveProvider,
  deleteProvider,
  getStoredChannels,
  saveChannels,
} from '@/utils/storage';
import { parseM3U, validateMACAddress, fetchMACChannels } from '@/utils/parser';
import { Provider } from '@/types';

export default function ProvidersScreen() {
  const [providers, setProviders] = useState<Provider[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [newProvider, setNewProvider] = useState({
    name: '',
    type: 'mac' as 'mac' | 'm3u',
    url: '',
    macAddress: '',
    username: '',
    password: '',
  });

  useEffect(() => {
    loadProviders();
  }, []);

  const loadProviders = async () => {
    try {
      const storedProviders = await getStoredProviders();
      setProviders(storedProviders);
    } catch (error) {
      console.error('Error loading providers:', error);
    }
  };

  const resetForm = () => {
    setNewProvider({
      name: '',
      type: 'mac',
      url: '',
      macAddress: '',
      username: '',
      password: '',
    });
  };

  const validateForm = (): boolean => {
    if (!newProvider.name.trim()) {
      Alert.alert('Error', 'Provider name is required');
      return false;
    }

    if (!newProvider.url.trim()) {
      Alert.alert('Error', 'URL is required');
      return false;
    }

    if (newProvider.type === 'mac') {
      if (!newProvider.macAddress.trim()) {
        Alert.alert('Error', 'MAC address is required for MAC providers');
        return false;
      }
      
      if (!validateMACAddress(newProvider.macAddress)) {
        Alert.alert('Error', 'Invalid MAC address format. Use format: 00:A1:79:XX:XX:XX');
        return false;
      }
    }

    return true;
  };

  const addProvider = async () => {
    if (!validateForm()) return;

    setIsLoading(true);
    try {
      const provider: Provider = {
        id: Date.now().toString(),
        name: newProvider.name,
        type: newProvider.type,
        url: newProvider.url,
        macAddress: newProvider.type === 'mac' ? newProvider.macAddress : undefined,
        username: newProvider.username || undefined,
        password: newProvider.password || undefined,
        isActive: true,
        channelCount: 0,
        lastUpdated: new Date().toISOString(),
      };

      await saveProvider(provider);
      await loadChannelsFromProvider(provider);
      await loadProviders();
      
      setShowAddModal(false);
      resetForm();
      Alert.alert('Success', 'Provider added successfully');
    } catch (error) {
      Alert.alert('Error', 'Failed to add provider');
    } finally {
      setIsLoading(false);
    }
  };

  const loadChannelsFromProvider = async (provider: Provider) => {
    try {
      let channels: Channel[] = [];
      
      if (provider.type === 'mac') {
        // Load channels from MAC provider
        channels = await fetchMACChannels({
          url: provider.url,
          macAddress: provider.macAddress,
          username: provider.username,
          password: provider.password,
        });
      } else if (provider.type === 'm3u') {
        // Load channels from M3U playlist
        const playlistInfo = await parseM3U(provider.url);
        channels = playlistInfo.channels.map(channel => ({
          ...channel,
          providerId: provider.id,
        }));
      }
      
      // Get existing channels and merge
      const existingChannels = await getStoredChannels();
      // Remove existing channels from this provider first
      const filteredExisting = existingChannels.filter(ch => ch.providerId !== provider.id);
      const updatedChannels = [...filteredExisting, ...channels];
      
      await saveChannels(updatedChannels);
      
      // Update provider with channel count
      provider.channelCount = channels.length;
      await saveProvider(provider);
      
      console.log(`Loaded ${channels.length} channels from ${provider.name}`);
    } catch (error) {
      console.error('Error loading channels:', error);
      throw error;
    }
  };

  const removeProvider = async (providerId: string) => {
    Alert.alert(
      'Remove Provider',
      'Are you sure you want to remove this provider? All associated channels will be deleted.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteProvider(providerId);
              
              // Remove channels from this provider
              const existingChannels = await getStoredChannels();
              const filteredChannels = existingChannels.filter(
                channel => channel.providerId !== providerId
              );
              await saveChannels(filteredChannels);
              
              await loadProviders();
              Alert.alert('Success', 'Provider removed successfully');
            } catch (error) {
              Alert.alert('Error', 'Failed to remove provider');
            }
          },
        },
      ]
    );
  };

  const refreshProvider = async (provider: Provider) => {
    setIsLoading(true);
    try {
      await loadChannelsFromProvider(provider);
      await loadProviders();
      Alert.alert('Success', 'Provider refreshed successfully');
    } catch (error) {
      Alert.alert('Error', 'Failed to refresh provider');
    } finally {
      setIsLoading(false);
    }
  };

  const renderProvider = (provider: Provider) => (
    <View key={provider.id} style={styles.providerCard}>
      <View style={styles.providerHeader}>
        <View style={styles.providerInfo}>
          <Text style={styles.providerName}>{provider.name}</Text>
          <Text style={styles.providerType}>
            {provider.type.toUpperCase()} Provider
          </Text>
          <Text style={styles.providerDetails}>
            {provider.channelCount} channels • Last updated: {new Date(provider.lastUpdated).toLocaleDateString()}
          </Text>
        </View>
        
        <View style={styles.providerStatus}>
          {provider.isActive ? (
            <CheckCircle size={24} color="#10B981" />
          ) : (
            <XCircle size={24} color="#EF4444" />
          )}
        </View>
      </View>

      <View style={styles.providerActions}>
        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => refreshProvider(provider)}
        >
          <Download size={16} color="#3B82F6" />
          <Text style={styles.actionButtonText}>Refresh</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => removeProvider(provider.id)}
        >
          <Trash2 size={16} color="#EF4444" />
          <Text style={[styles.actionButtonText, { color: '#EF4444' }]}>Remove</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>IPTV Providers</Text>
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => setShowAddModal(true)}
          >
            <Plus size={20} color="#FFFFFF" />
            <Text style={styles.addButtonText}>Add Provider</Text>
          </TouchableOpacity>
        </View>

        {/* Providers List */}
        {providers.length > 0 ? (
          providers.map(renderProvider)
        ) : (
          <View style={styles.emptyState}>
            <Settings size={64} color="#6B7280" />
            <Text style={styles.emptyStateTitle}>No Providers Added</Text>
            <Text style={styles.emptyStateText}>
              Add your first IPTV provider to start watching channels
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Add Provider Modal */}
      <Modal
        visible={showAddModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Add New Provider</Text>
            <TouchableOpacity
              onPress={() => {
                setShowAddModal(false);
                resetForm();
              }}
            >
              <Text style={styles.cancelButton}>Cancel</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            {/* Provider Name */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Provider Name</Text>
              <TextInput
                style={styles.textInput}
                placeholder="Enter provider name"
                placeholderTextColor="#6B7280"
                value={newProvider.name}
                onChangeText={(text) => setNewProvider({ ...newProvider, name: text })}
              />
            </View>

            {/* Provider Type */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Provider Type</Text>
              <View style={styles.typeSelector}>
                <TouchableOpacity
                  style={[
                    styles.typeButton,
                    newProvider.type === 'mac' && styles.typeButtonActive
                  ]}
                  onPress={() => setNewProvider({ ...newProvider, type: 'mac' })}
                >
                  <Wifi size={16} color={newProvider.type === 'mac' ? '#FFFFFF' : '#6B7280'} />
                  <Text style={[
                    styles.typeButtonText,
                    newProvider.type === 'mac' && styles.typeButtonTextActive
                  ]}>
                    MAC Address
                  </Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={[
                    styles.typeButton,
                    newProvider.type === 'm3u' && styles.typeButtonActive
                  ]}
                  onPress={() => setNewProvider({ ...newProvider, type: 'm3u' })}
                >
                  <List size={16} color={newProvider.type === 'm3u' ? '#FFFFFF' : '#6B7280'} />
                  <Text style={[
                    styles.typeButtonText,
                    newProvider.type === 'm3u' && styles.typeButtonTextActive
                  ]}>
                    M3U Playlist
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Server URL */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Server URL</Text>
              <TextInput
                style={styles.textInput}
                placeholder="http://example.com:8080"
                placeholderTextColor="#6B7280"
                value={newProvider.url}
                onChangeText={(text) => setNewProvider({ ...newProvider, url: text })}
                autoCapitalize="none"
                keyboardType="url"
              />
            </View>

            {/* MAC Address (only for MAC type) */}
            {newProvider.type === 'mac' && (
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>MAC Address</Text>
                <TextInput
                  style={styles.textInput}
                  placeholder="00:A1:79:XX:XX:XX"
                  placeholderTextColor="#6B7280"
                  value={newProvider.macAddress}
                  onChangeText={(text) => setNewProvider({ ...newProvider, macAddress: text })}
                  autoCapitalize="characters"
                />
                <Text style={styles.inputHint}>
                  Enter MAC address starting with 00:A1:79:
                </Text>
              </View>
            )}

            {/* Username (optional) */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Username (Optional)</Text>
              <TextInput
                style={styles.textInput}
                placeholder="Enter username"
                placeholderTextColor="#6B7280"
                value={newProvider.username}
                onChangeText={(text) => setNewProvider({ ...newProvider, username: text })}
                autoCapitalize="none"
              />
            </View>

            {/* Password (optional) */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Password (Optional)</Text>
              <TextInput
                style={styles.textInput}
                placeholder="Enter password"
                placeholderTextColor="#6B7280"
                value={newProvider.password}
                onChangeText={(text) => setNewProvider({ ...newProvider, password: text })}
                secureTextEntry
                autoCapitalize="none"
              />
            </View>
          </ScrollView>

          <View style={styles.modalFooter}>
            <TouchableOpacity
              style={[styles.saveButton, isLoading && styles.saveButtonDisabled]}
              onPress={addProvider}
              disabled={isLoading}
            >
              {isLoading ? (
                <ActivityIndicator size="small" color="#FFFFFF" />
              ) : (
                <Text style={styles.saveButtonText}>Add Provider</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  title: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#3B82F6',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 8,
  },
  providerCard: {
    backgroundColor: '#1F2937',
    marginHorizontal: 16,
    marginBottom: 12,
    borderRadius: 12,
    padding: 16,
  },
  providerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  providerInfo: {
    flex: 1,
  },
  providerName: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  providerType: {
    color: '#3B82F6',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  providerDetails: {
    color: '#9CA3AF',
    fontSize: 12,
  },
  providerStatus: {
    marginLeft: 12,
  },
  providerActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    marginLeft: 8,
  },
  actionButtonText: {
    color: '#3B82F6',
    fontSize: 14,
    fontWeight: '500',
    marginLeft: 4,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 48,
  },
  emptyStateTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateText: {
    color: '#9CA3AF',
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#111827',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#374151',
  },
  modalTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  cancelButton: {
    color: '#3B82F6',
    fontSize: 16,
    fontWeight: '500',
  },
  modalContent: {
    flex: 1,
    padding: 16,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  textInput: {
    backgroundColor: '#1F2937',
    borderWidth: 1,
    borderColor: '#374151',
    borderRadius: 8,
    padding: 12,
    color: '#FFFFFF',
    fontSize: 16,
  },
  inputHint: {
    color: '#6B7280',
    fontSize: 12,
    marginTop: 4,
  },
  typeSelector: {
    flexDirection: 'row',
  },
  typeButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#374151',
    padding: 12,
    borderRadius: 8,
    marginRight: 8,
  },
  typeButtonActive: {
    backgroundColor: '#3B82F6',
  },
  typeButtonText: {
    color: '#6B7280',
    fontSize: 14,
    fontWeight: '500',
    marginLeft: 8,
  },
  typeButtonTextActive: {
    color: '#FFFFFF',
  },
  modalFooter: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#374151',
  },
  saveButton: {
    backgroundColor: '#3B82F6',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveButtonDisabled: {
    opacity: 0.5,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
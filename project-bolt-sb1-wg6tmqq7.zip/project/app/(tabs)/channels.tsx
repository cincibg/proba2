import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  TextInput,
  Alert,
} from 'react-native';
import { Search, Play, Star, StarOff } from 'lucide-react-native';
import { getStoredChannels, saveFavoriteChannels, getFavoriteChannels } from '@/utils/storage';
import { Channel } from '@/types';

export default function ChannelsScreen() {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [filteredChannels, setFilteredChannels] = useState<Channel[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [categories, setCategories] = useState<string[]>(['All']);

  useEffect(() => {
    loadChannels();
    loadFavorites();
  }, []);

  useEffect(() => {
    filterChannels();
  }, [channels, searchQuery, selectedCategory]);

  const loadChannels = async () => {
    try {
      const storedChannels = await getStoredChannels();
      console.log(`Loaded ${storedChannels.length} channels from storage`);
      setChannels(storedChannels);
      
      // Extract unique categories
      const uniqueCategories = ['All', ...new Set(storedChannels.map(ch => ch.category).filter(Boolean))];
      setCategories(uniqueCategories);
    } catch (error) {
      console.error('Error loading channels:', error);
    }
  };

  const loadFavorites = async () => {
    try {
      const favoriteChannels = await getFavoriteChannels();
      setFavorites(favoriteChannels);
    } catch (error) {
      console.error('Error loading favorites:', error);
    }
  };

  const filterChannels = () => {
    let filtered = channels;

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(channel =>
        channel.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        channel.country?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filter by category
    if (selectedCategory !== 'All') {
      filtered = filtered.filter(channel => channel.category === selectedCategory);
    }

    setFilteredChannels(filtered);
  };

  const toggleFavorite = async (channelId: string) => {
    try {
      const newFavorites = favorites.includes(channelId)
        ? favorites.filter(id => id !== channelId)
        : [...favorites, channelId];
      
      setFavorites(newFavorites);
      await saveFavoriteChannels(newFavorites);
    } catch (error) {
      Alert.alert('Error', 'Failed to update favorites');
    }
  };

  const playChannel = (channel: Channel) => {
    Alert.alert(
      'Play Channel',
      `Playing: ${channel.name}`,
      [{ text: 'OK' }]
    );
  };

  const renderChannel = ({ item }: { item: Channel }) => {
    const isFavorite = favorites.includes(item.id);
    
    return (
      <View style={styles.channelItem}>
        <Image
          source={{ uri: item.logo || 'https://via.placeholder.com/60x60/374151/FFFFFF?text=TV' }}
          style={styles.channelLogo}
        />
        
        <View style={styles.channelInfo}>
          <Text style={styles.channelName} numberOfLines={1}>
            {item.name}
          </Text>
          <Text style={styles.channelDetails}>
            {item.country} • {item.category}
          </Text>
          {item.language && (
            <Text style={styles.channelLanguage}>
              Language: {item.language}
            </Text>
          )}
        </View>
        
        <View style={styles.channelActions}>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => toggleFavorite(item.id)}
          >
            {isFavorite ? (
              <Star size={20} color="#F59E0B" fill="#F59E0B" />
            ) : (
              <StarOff size={20} color="#6B7280" />
            )}
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, styles.playButton]}
            onPress={() => playChannel(item)}
          >
            <Play size={20} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const renderCategoryFilter = () => (
    <View style={styles.categoryContainer}>
      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        data={categories}
        keyExtractor={(item) => item}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[
              styles.categoryButton,
              selectedCategory === item && styles.categoryButtonActive
            ]}
            onPress={() => setSelectedCategory(item)}
          >
            <Text style={[
              styles.categoryButtonText,
              selectedCategory === item && styles.categoryButtonTextActive
            ]}>
              {item}
            </Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <Search size={20} color="#6B7280" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search channels..."
          placeholderTextColor="#6B7280"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      {/* Category Filter */}
      {renderCategoryFilter()}

      {/* Results Header */}
      <View style={styles.resultsHeader}>
        <Text style={styles.resultsText}>
          {filteredChannels.length} channels found
        </Text>
      </View>

      {/* Channels List */}
      <FlatList
        data={filteredChannels}
        keyExtractor={(item) => item.id}
        renderItem={renderChannel}
        style={styles.channelsList}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateText}>
              {channels.length === 0
                ? 'No channels available. Add providers to load channels.'
                : 'No channels match your search criteria.'
              }
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1F2937',
    margin: 16,
    borderRadius: 8,
    paddingHorizontal: 12,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 16,
    paddingVertical: 12,
  },
  categoryContainer: {
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  categoryButton: {
    backgroundColor: '#374151',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
  },
  categoryButtonActive: {
    backgroundColor: '#3B82F6',
  },
  categoryButtonText: {
    color: '#D1D5DB',
    fontSize: 14,
    fontWeight: '500',
  },
  categoryButtonTextActive: {
    color: '#FFFFFF',
  },
  resultsHeader: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  resultsText: {
    color: '#9CA3AF',
    fontSize: 14,
  },
  channelsList: {
    flex: 1,
  },
  channelItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1F2937',
    marginHorizontal: 16,
    marginBottom: 8,
    borderRadius: 8,
    padding: 12,
  },
  channelLogo: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  channelInfo: {
    flex: 1,
  },
  channelName: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  channelDetails: {
    color: '#9CA3AF',
    fontSize: 14,
    marginBottom: 2,
  },
  channelLanguage: {
    color: '#6B7280',
    fontSize: 12,
  },
  channelActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionButton: {
    padding: 8,
    marginLeft: 8,
  },
  playButton: {
    backgroundColor: '#3B82F6',
    borderRadius: 6,
  },
  emptyState: {
    padding: 32,
    alignItems: 'center',
  },
  emptyStateText: {
    color: '#9CA3AF',
    fontSize: 16,
    textAlign: 'center',
  },
});